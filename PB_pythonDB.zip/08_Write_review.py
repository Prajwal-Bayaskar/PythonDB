import pymysql

con=pymysql.connect(host='bkk4vuwuyqau7xygwcx4-mysql.services.clever-cloud.com',user='uofdhaylgfeoc4gi',password='8OGfVoqQAb8sZz4aLvns',database='bkk4vuwuyqau7xygwcx4')
curs=con.cursor()

try:
    code=int(input("Enter bookcode to give review : "))
    curs.execute("select * from books where Bookcode=%d"%code)
    data=curs.fetchone()
    print(data)
    if data:
        review=input("Enter you review :")
        curs.execute("update books set review='%s' where Bookcode=%d"%(review,code))
        con.commit()
        print("Thanks for your precious review...")
    else:
        print("Sorry... book  does not exist ")
except Exception as e:
    print('Error :',e)

con.close()

    
