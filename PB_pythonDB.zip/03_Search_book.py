import pymysql

code=int(input('Enter the bookcode : '))
con=pymysql.connect(host='bkk4vuwuyqau7xygwcx4-mysql.services.clever-cloud.com',user='uofdhaylgfeoc4gi',password='8OGfVoqQAb8sZz4aLvns',database='bkk4vuwuyqau7xygwcx4')

curs=con.cursor()

try:
    curs.execute("select * from books where Bookcode='%d'" %code)
    res=curs.fetchone()

    print(res)

except Exception as e:
    print("Sorry book does not exist with the code you entered")
    print('Error:',e)

con.close()