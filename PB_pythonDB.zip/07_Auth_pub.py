import pymysql
con=pymysql.connect(host='bkk4vuwuyqau7xygwcx4-mysql.services.clever-cloud.com',user='uofdhaylgfeoc4gi',password='8OGfVoqQAb8sZz4aLvns',database='bkk4vuwuyqau7xygwcx4')
curs=con.cursor()

try:
    auth=input("Enter the author name : ")
    pub=int(input("Enter the publication year :"))

    curs.execute("select * from books where Author='%s' and Publication=%d"%(auth,pub))
    data=curs.fetchall()
    print(data)

except Exception as e:
    print("Error:",e)

con.close()