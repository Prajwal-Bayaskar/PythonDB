import pymysql
con=pymysql.connect(host='bkk4vuwuyqau7xygwcx4-mysql.services.clever-cloud.com',user='uofdhaylgfeoc4gi',password='8OGfVoqQAb8sZz4aLvns',database='bkk4vuwuyqau7xygwcx4')

curs=con.cursor()

curs.execute("select Bookname from books ")
data=curs.fetchall()

print("List of the books are:",data)
con.close()
