import pymysql

con=pymysql.connect(host='bkk4vuwuyqau7xygwcx4-mysql.services.clever-cloud.com',user='uofdhaylgfeoc4gi',password='8OGfVoqQAb8sZz4aLvns',database='bkk4vuwuyqau7xygwcx4')
curs=con.cursor()


try:

    Bookcode=int(input("Enter Bookcode :"))
    Bookname=input("Enter bookname :")
    Category=input("Enter the category : ")
    Author=input("Enter Author Name :")
    Publication=int(input("Enter the publication year :"))
    Edition=int(input("Enter edition number :"))
    Price=float(input("Enter the price of the book : "))
    review=input("Enter review if you finished reading or else keep it blank :")

    curs.execute("INSERT INTO books Values(%d,'%s','%s','%s',%d,%d,'%.2f','%s')"%(Bookcode,Bookname,Category,Author,Publication,Edition,Price,review))
    con.commit()
    print("Book Inserted Successfully ")
except Exception as e:
    print("Error:",e)

con.close()

