import pymysql

con=pymysql.connect(host='bkk4vuwuyqau7xygwcx4-mysql.services.clever-cloud.com',user='uofdhaylgfeoc4gi',password='8OGfVoqQAb8sZz4aLvns',database='bkk4vuwuyqau7xygwcx4')
curs=con.cursor()

try:
    code=int(input("Enter the bookcode to update the book price: "))
    curs.execute("select * from books where bookcode=%d"%code)
    data=curs.fetchone()
    if data:
        newp=int(input("Enter the updated price :"))
        curs.execute("update books set price=%d"%newp)
        con.commit()
        print("Book price updated Successfully...")
    else:
        print("Sorry book does not exist")
except Exception as e:
    print("Error :",e)

con.close()